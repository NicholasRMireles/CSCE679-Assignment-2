function _1(md){return(
md `# Assignment 2`
)}

function _d3(require){return(
require('d3@6')
)}

function _d3tip(require){return(
require("https://cdnjs.cloudflare.com/ajax/libs/d3-tip/0.9.1/d3-tip.js")
)}

function _temps(d3){return(
d3.csv('https://raw.githubusercontent.com/xiameng552180/CSCE-679-Data-Visualization-Assignment2/refs/heads/main/temperature_daily.csv', ({date, max_temperature, min_temperature}) => ({date: String(date), max_temperature: +max_temperature, min_temperature: +min_temperature}))
)}

function _months(){return(
["December", "November", "October", "September", "August", "July", "June", "May", "April", "March", "February", "January"]
)}

function _years(temps)
{
  let yearsArray = []  
  for (let i = 0; i < temps.length; i+=365) {
    yearsArray.push(temps[i].date.substring(0,4))
  }

  return yearsArray
}


function _allData(temps)
{
  // Create empty array to collect min/max per month
  let monthTemps = []

  // Create variables to compare the min/max per month
  let month_year = temps[0].date.substring(0,7)
  let month = ""
  let year = temps[0].date.substring(0,4)
  let min = 100
  let max = 0
  let min_daily = []
  let max_daily = []
  
  for (let i = 0; i < temps.length; i++) {
    // When the month changes, push the last month's results to the array. Each entry in the array is a new month
    if (month_year != temps[i].date.substring(0,7)) {

      // Grab the year for the data entry
      year = temps[i-1].date.substring(0,4)

      // Convert month numerials to words
      if (temps[i-1].date.substring(5,7) === "01") {month = "January"}
      else if (temps[i-1].date.substring(5,7) === "02") {month = "February"}
      else if (temps[i-1].date.substring(5,7) === "03") {month = "March"}
      else if (temps[i-1].date.substring(5,7) === "04") {month = "April"}
      else if (temps[i-1].date.substring(5,7) === "05") {month = "May"}
      else if (temps[i-1].date.substring(5,7) === "06") {month = "June"}
      else if (temps[i-1].date.substring(5,7) === "07") {month = "July"}
      else if (temps[i-1].date.substring(5,7) === "08") {month = "August"}
      else if (temps[i-1].date.substring(5,7) === "09") {month = "September"}
      else if (temps[i-1].date.substring(5,7) === "10") {month = "October"}
      else if (temps[i-1].date.substring(5,7) === "11") {month = "November"}
      else if (temps[i-1].date.substring(5,7) === "12") {month = "December"}

      // Push the year-month, month as text, year, min for the month, max for the month, and two arrays for the daily min and max temps
      monthTemps.push({month_year, month, year, min, max, min_daily, max_daily})

      // reset the compare variables to analyze for a new month
      month_year = temps[i].date.substring(0,7)
      month = ""
      year = "0000"
      min = 100
      max = 0
      min_daily = []
      max_daily = []
    }

    // Push the daily temperature for the monthly temps array
    min_daily.push(temps[i].min_temperature)
    max_daily.push(temps[i].max_temperature)

    // Compare the min and max. Replace is new min or max is lower or higher 
    if(temps[i].min_temperature < min) {
      min = temps[i].min_temperature
    }
    if(temps[i].max_temperature > max) {
      max = temps[i].max_temperature
    }
  }
  // Push the last month like the loop (loop does not handle this automatically)
  year = temps[temps.length - 1].date.substring(0,4)
  if (temps[temps.length - 1].date.substring(5,7) === "01") {month = "January"}
  else if (temps[temps.length - 1].date.substring(5,7) === "02") {month = "February"}
  else if (temps[temps.length - 1].date.substring(5,7) === "03") {month = "March"}
  else if (temps[temps.length - 1].date.substring(5,7) === "04") {month = "April"}
  else if (temps[temps.length - 1].date.substring(5,7) === "05") {month = "May"}
  else if (temps[temps.length - 1].date.substring(5,7) === "06") {month = "June"}
  else if (temps[temps.length - 1].date.substring(5,7) === "07") {month = "July"}
  else if (temps[temps.length - 1].date.substring(5,7) === "08") {month = "August"}
  else if (temps[temps.length - 1].date.substring(5,7) === "09") {month = "September"}
  else if (temps[temps.length - 1].date.substring(5,7) === "10") {month = "October"}
  else if (temps[temps.length - 1].date.substring(5,7) === "11") {month = "November"}
  else if (temps[temps.length - 1].date.substring(5,7) === "12") {month = "December"}

  // Push the data
  monthTemps.push({month_year, month, year, min, max, min_daily, max_daily})

  // Return the array of parsed data by month
  return monthTemps
}


function _y_scale(d3,months,height){return(
d3.scaleBand()
.domain(months)
.range([height, 0])
)}

function _x_scale(d3,years,width){return(
d3.scaleBand()
.domain(years)
.range([0, width-70])
)}

function _margin(){return(
{ top: 30, left: 60, right: 5, bottom: 100 }
)}

function _height(){return(
500
)}

function _maxDataMap(d3,DOM,width,height,margin,x_scale,y_scale,allData)
{
  // Set up the drawing space for the heatmap
  const svg = d3.select(DOM.svg(width, height))
  const g = svg.attr('width', width - margin.left)
   .attr('height', height + margin.top + margin.bottom)
   .append('g')
   .attr('transform', 'translate(' + margin.left + ', 0)')
   .style("overflow", "visible");

  // Define the range of colors to be used by the heatmap
  const color_scale = d3.scaleLinear()
  .interpolate(() => d3.interpolateYlOrRd)
  .domain([20, 38])

  // Create the axes
  g.append('g')
    .attr('transform', 'translate(0,' -  height +')')
    .call(d3.axisTop(x_scale))
  g.append('g')
    .call(d3.axisLeft(y_scale))

  // Create the settings for the tooltip (mouse hover)
  const tooltip = svg
    .append("text")
    .attr("class", "tooltip")
    .style("background-color", "red")
    .attr("fill", "black")
    .style("pointer-events", "none")
    .style("opacity", 10)
    .style("position", "absolute")

  // Create the cells for the heatmap
  svg.selectAll()
    // Read from the parsed data array
    .data(allData)
    .enter()
    .append('rect')
    // Opacity set lower to help showcase broken tooltip
    .style("opacity", .8)
    // Pull and match the year for the x axis
    .attr('x', (d) => x_scale(d.year) + margin.left+3)
    // Pull and match the month for the y axis
    .attr('y', (d) => y_scale(d.month)+3)
    // Fit the data within the image size
    .attr('width', x_scale.bandwidth()-2)
    .attr('height', (d) => 40)
    // Defines the data being used for the map
    // Change d.<min/max> to be map the data for the min or max temperatures respectively
    .attr('fill', (d) => color_scale(d.max)) 

    // Tooltip Listening Events
    .on("mouseover", (evt, d) => {
      const [mx, my] = d3.pointer(evt);
      tooltip
        .attr("x", mx)
        .attr("y", my)
        .text(`Date: ${d.month_year}; Max: ${d.max}; Min: ${d.min}`);
    })
    // Clear the tooltip when mouse is not on an entry
    .on("mouseout", () => {
      tooltip.text("");
    })

  // Write the title for the map
  svg.append("text")
      .attr("font-size","25px")
      .text("Heat Map of Max Temperatures By Month in Hong Kong (1997-2017)")
      .attr("x", 20)
      .attr("y", height+50)

  // Write the values for the legend
  svg.append("text")
      .attr("font-size","15px")
      .text("7°C")
      .attr("x", width-275)
      .attr("y", height+45)

  svg.append("text")
      .attr("font-size","15px")
      .text("37°C")
      .attr("x", width-45)
      .attr("y", height+45)

  // Set the legend's color ranges
  var colors = [ 'rgb(255,255,150)', 'rgb(255,0,100)' ];

  // Create the legend
  var grad = svg.append('defs')
    .append('linearGradient')
    .attr('id', 'grad')
    .attr('x1', '0%')
    .attr('x2', '100%')
    .attr('y1', '0%')
    .attr('y2', '100%');
  
  grad.selectAll('stop')
    .data(colors)
    .enter()
    .append('stop')
    .style('stop-color', function(d){ return d; })
    .attr('offset', function(d,i){
      return 100 * (i / (colors.length - 1)) + '%';
    })
  
  svg.append('rect')
    .attr('x', width-250)
    .attr('y', height+30)
    .attr('width', 200)
    .attr('height', 20)
    .style('fill', 'url(#grad)');
    svg.selectAll()

  // Return the heatmap
  return svg.node()
}


function _minDataMap(d3,DOM,width,height,margin,x_scale,y_scale,allData)
{
  // Set up the drawing space for the heatmap
  const svg = d3.select(DOM.svg(width, height))
  const g = svg.attr('width', width - margin.left)
   .attr('height', height + margin.top + margin.bottom)
   .append('g')
   .attr('transform', 'translate(' + margin.left + ', 0)')
   .style("overflow", "visible");

  // Define the range of colors to be used by the heatmap
  const color_scale = d3.scaleLinear()
  .interpolate(() => d3.interpolateYlOrRd)
  .domain([0, 30])

  // Create the axes
  g.append('g')
    .attr('transform', 'translate(0,' -  height +')')
    .call(d3.axisTop(x_scale))
  g.append('g')
    .call(d3.axisLeft(y_scale))

  // Create the settings for the tooltip (mouse hover)
  const tooltip = svg
    .append("text")
    .attr("class", "tooltip")
    .style("background-color", "red")
    .attr("fill", "black")
    .style("pointer-events", "none")
    .style("opacity", 10)
    .style("position", "absolute")

  // Create the cells for the heatmap
  svg.selectAll()
    // Read from the parsed data array
    .data(allData)
    .enter()
    .append('rect')
    // Opacity set lower to help showcase broken tooltip
    .style("opacity", .8)
    // Pull and match the year for the x axis
    .attr('x', (d) => x_scale(d.year) + margin.left+3)
    // Pull and match the month for the y axis
    .attr('y', (d) => y_scale(d.month)+3)
    // Fit the data within the image size
    .attr('width', x_scale.bandwidth()-2)
    .attr('height', (d) => 40)
    // Defines the data being used for the map
    // Change d.<min/max> to be map the data for the min or max temperatures respectively
    .attr('fill', (d) => color_scale(d.min)) 

    // Tooltip Listening Events
    .on("mouseover", (evt, d) => {
      const [mx, my] = d3.pointer(evt);
      tooltip
        .attr("x", mx)
        .attr("y", my)
        .text(`Date: ${d.month_year}; Max: ${d.max}; Min: ${d.min}`);
    })
    // Clear the tooltip when mouse is not on an entry
    .on("mouseout", () => {
      tooltip.text("");
    })

  // Write the title for the map
  svg.append("text")
      .attr("font-size","25px")
      .text("Heat Map of Min Temperatures By Month in Hong Kong (1997-2017)")
      .attr("x", 20)
      .attr("y", height+50)

  // Write the values for the legend
  svg.append("text")
      .attr("font-size","15px")
      .text("3°C")
      .attr("x", width-275)
      .attr("y", height+45)
      
  svg.append("text")
      .attr("font-size","15px")
      .text("33°C")
      .attr("x", width-45)
      .attr("y", height+45)
  
  // Set the legend's color ranges
  var colors = [ 'rgb(255,255,150)', 'rgb(255,0,0)' ];

  // Create the legend
  var grad = svg.append('defs')
    .append('linearGradient')
    .attr('id', 'grad')
    .attr('x1', '0%')
    .attr('x2', '100%')
    .attr('y1', '0%')
    .attr('y2', '100%');
  
  grad.selectAll('stop')
    .data(colors)
    .enter()
    .append('stop')
    .style('stop-color', function(d){ return d; })
    .attr('offset', function(d,i){
      return 100 * (i / (colors.length - 1)) + '%';
    })
  
  svg.append('rect')
    .attr('x', width-250)
    .attr('y', height+30)
    .attr('width', 200)
    .attr('height', 20)
    .style('fill', 'url(#grad)');
    svg.selectAll()

  // Return the heatmap
  return svg.node()
}


export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  main.variable(observer("d3tip")).define("d3tip", ["require"], _d3tip);
  main.variable(observer("temps")).define("temps", ["d3"], _temps);
  main.variable(observer("months")).define("months", _months);
  main.variable(observer("years")).define("years", ["temps"], _years);
  main.variable(observer("allData")).define("allData", ["temps"], _allData);
  main.variable(observer("y_scale")).define("y_scale", ["d3","months","height"], _y_scale);
  main.variable(observer("x_scale")).define("x_scale", ["d3","years","width"], _x_scale);
  main.variable(observer("margin")).define("margin", _margin);
  main.variable(observer("height")).define("height", _height);
  main.variable(observer("maxDataMap")).define("maxDataMap", ["d3","DOM","width","height","margin","x_scale","y_scale","allData"], _maxDataMap);
  main.variable(observer("minDataMap")).define("minDataMap", ["d3","DOM","width","height","margin","x_scale","y_scale","allData"], _minDataMap);
  return main;
}
